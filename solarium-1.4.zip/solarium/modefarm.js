inlets = 1;
outlets = 2;
var modeArr = new Array();
var outlist = new Array();

function list() {
	var a = arrayfromargs(arguments);	
		
		for (i=0;i<12;i++) {
			var lastelement = a[a.length-1];
			for (k=0;k<a.length;k++) {		
				modeArr[k] = a[k]+lastelement*i;
				
				}
			outlet(0,modeArr);			
		}			
	}